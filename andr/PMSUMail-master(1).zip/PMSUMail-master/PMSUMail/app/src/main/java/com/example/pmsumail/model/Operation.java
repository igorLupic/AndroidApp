package com.example.pmsumail.model;

public enum Operation {
    MOVE,
    COPY,
    DELETE
}
