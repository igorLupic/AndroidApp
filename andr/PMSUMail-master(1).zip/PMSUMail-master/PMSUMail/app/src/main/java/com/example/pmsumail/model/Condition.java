package com.example.pmsumail.model;

public enum  Condition {
    TO,
    FROM,
    CC,
    SUBJECT
}
